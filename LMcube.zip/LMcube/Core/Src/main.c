/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define _5SEC 5000
#define _3SEC 3000
#define _2SEC 2000
#define _1SEC 1000
#define _0SEC01 10
#define PUSH0SEC 0x01
#define PUSH1SEC 0x02
#define PUSH2SEC 0x04
#define PUSH3SEC 0x08
#define PUSH4SEC 0x10
#define PUSH5SEC 0x20
#define ADCLIGHT 0x01
#define ADCBATT  0x02
#define ADCLIGHTTIME 10
#define ADCBATTTIME 30
#define ADCLOOPTIME 75
#define BLINKCYCLE 200
#define BATTLIMIT 0x049A //About 0.95V
#define COLOR_BLUE 0
#define COLOR_RED 1
#define SCANVIEW 0
#define HOLDVIEW 1
#define AUTOOFFTIME 40000


//#define MILLIAMP1STEP  // (3.3/4096)*1000
//#define EV00MAX 5 //EV0 2.5LUX 0.5mV x8STEP5
//#define EV01MAX 12 //EV1 5LUX 1.2mV x8STEP12
//#define EV02MAX 23 //EV2 10LUX 2.3mV x8STEP23
//#define EV03MAX 50 //EV3 20LUX 5mV x8STEP50
//#define EV04MAX 99 //EV4 40LUX 10mV x8STEP99
//#define EV05MAX 228 //EV5 80LUX 23mV x8STEP228
//#define EV06MAX 596 //EV6 160LUX 60mV x8STEP596
//#define EV07MAX 1192 //EV7 320LUX 120mV x8STEP1192
//#define EV08MAX 2185 //EV8 640LUX 220mV x8STEP2185
//#define EV09MAX 4965 //EV9 1280LUX 500mV x8STEP4965
//#define EV10MAX 8937 //EV10 2560LUX 900mV x8STEP8937
//#define EV11MAX 12909 //EV11 5120LUX 1300mV x8STEP12909
//#define EV12MAX 13238 //EV12 10240LUX 1333mV x8STEP13238
//#define EV13MAX 19661 //EV13 20480LUX 1980mV x8STEP19661
//#define EV14MAX 22282 //EV14 40960LUX 2244mV x8STEP22282
//#define EV15MAX 27525
//#define EV16MAX 29491
//#define EV17MAX 30000
//#define EV18MAX 30001
//#define EV19MAX 30002
//#define EV20MAX 30003
//#define EV21MAX 30004
//#define EV22MAX 30005
//#define EV23MAX 30006
//#define EV24MAX 30007
//#define EV25MAX 30008
//#define EV26MAX 30009
//#define EV27MAX 30010
//#define EV28MAX 30011
//#define EV29MAX 30012
//#define EV30MAX 30013
//#define EV31MAX 30014


//#define MILLIAMP1STEP  // (3.3/4096)*1000*8
//#define EV00MAX 3
//#define EV01MAX 7
//#define EV02MAX 15
//#define EV03MAX 28
//#define EV04MAX 59
//#define EV05MAX 118
//#define EV06MAX 246
//#define EV07MAX 426
//#define EV08MAX 918
//#define EV09MAX 1671
//#define EV10MAX 3441
//#define EV11MAX 7209
//#define EV12MAX 13107
//#define EV13MAX 20316
//#define EV14MAX 24248 // Dummy
//#define EV15MAX 24576 // Dummy
//#define EV16MAX 24904 // Dummy
//#define EV17MAX 25231 // Dummy
//#define EV18MAX 25559 // Dummy
//#define EV19MAX 25887 // Dummy
//#define EV20MAX 26214 // Dummy
//#define EV21MAX 26542 // Dummy
//#define EV22MAX 26870 // Dummy
//#define EV23MAX 27197 // Dummy
//#define EV24MAX 27525 // Dummy
//#define EV25MAX 27853 // Dummy
//#define EV26MAX 28180 // Dummy
//#define EV27MAX 28508 // Dummy
//#define EV28MAX 28836 // Dummy
//#define EV29MAX 29164 // Dummy
//#define EV30MAX 29491 // Dummy
//#define EV31MAX 29494 // Dummy



#define MILLIAMP1STEP  // (3.3/4096)*1000*8

#define EV00MAX 0
#define EV01MAX 1
#define EV02MAX 2
#define EV03MAX 3
#define EV04MAX 7
#define EV05MAX 15
#define EV06MAX 28
#define EV07MAX 59
#define EV08MAX 118
#define EV09MAX 246
#define EV10MAX 426
#define EV11MAX 918
#define EV12MAX 1671
#define EV13MAX 3441
#define EV14MAX 7209
#define EV15MAX 13107
#define EV16MAX 20316
#define EV17MAX 24248 // Dummy
#define EV18MAX 24576 // Dummy
#define EV19MAX 24904 // Dummy
#define EV20MAX 25231 // Dummy
#define EV21MAX 25559 // Dummy
#define EV22MAX 25887 // Dummy
#define EV23MAX 26214 // Dummy
#define EV24MAX 26542 // Dummy
#define EV25MAX 26870 // Dummy
#define EV26MAX 27197 // Dummy
#define EV27MAX 27525 // Dummy
#define EV28MAX 27853 // Dummy
#define EV29MAX 28180 // Dummy
#define EV30MAX 28508 // Dummy
#define EV31MAX 28836 // Dummy






/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;

UART_HandleTypeDef hlpuart1;

TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC_Init(void);
static void MX_LPUART1_UART_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

uint32_t last_ticktime = 0;
uint16_t adcmstime = 0;
uint8_t adcevent = 0;
uint8_t adcrunning = 0;
uint8_t sw_stat = 0;
uint16_t pushtime = 0;
uint8_t pushevent = 0;
uint8_t viewmode = 0;
uint8_t modecolor = 0;
uint8_t battlow = 0;
uint16_t blink_count = 0;
uint8_t blink = 0;
uint16_t batt = 0;
uint32_t offcount = 0;
//static uint16_t adc_buf[8];
uint16_t que_light[8];
uint16_t que_batt[8];
uint8_t que_light_point = 0;
uint8_t que_batt_point = 0;
uint16_t avg_light;
uint16_t avg_batt;
uint16_t ev_table[32] = {EV00MAX, EV01MAX, EV02MAX, EV03MAX, EV04MAX, EV05MAX, EV06MAX, EV07MAX, EV08MAX, EV09MAX,
				  EV10MAX, EV11MAX, EV12MAX, EV13MAX, EV14MAX, EV15MAX, EV16MAX, EV17MAX, EV18MAX, EV19MAX,
				  EV20MAX, EV21MAX, EV22MAX, EV23MAX, EV24MAX, EV25MAX, EV26MAX, EV27MAX, EV28MAX, EV29MAX,
				  EV30MAX, EV31MAX};

char bin2hex1d(uint8_t input_bin){
	uint8_t output;
	input_bin = input_bin & 0xF;
	if(10 <= input_bin){
		output = input_bin - 10 + 0x41;
	}
	else{
		output = input_bin + 0x30;
	}
	return (char)output;
}

uint8_t bin2hex2d(uint8_t input_bin, char* output_string){
	output_string[1] = bin2hex1d(input_bin & 0xF);
	output_string[0] = bin2hex1d((input_bin >> 4) & 0xF);
	return 0;
}

uint8_t bin2hex4d(uint16_t input_bin, char* output_string){
	output_string[3] = bin2hex1d(input_bin & 0xF);
	output_string[2] = bin2hex1d((input_bin >> 4) & 0xF);
	output_string[1] = bin2hex1d((input_bin >> 8) & 0xF);
	output_string[0] = bin2hex1d((input_bin >> 12) & 0xF);
	return 0;
}

void ms_edge(uint32_t diffms){

//	char txtsplit[] = "(";
//	HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);

	offcount = offcount + diffms;

	blink_count = blink_count + diffms;
	if((BLINKCYCLE>>1) > blink_count){
		blink = 1;
	}
	else{
		blink = 0;
	}
	if(BLINKCYCLE < blink_count){
		blink_count = 0;
	}

	adcmstime = adcmstime + diffms;
	if(ADCLOOPTIME <= adcmstime){
		adcmstime = 0;
	}

	if(ADCLIGHTTIME == adcmstime){
//		  char txtlightadc[] = "Light Adc Event\r\n";
//		  HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtlightadc, sizeof(txtlightadc), 100);
		adcevent |= ADCLIGHT;
	}
	if(ADCBATTTIME == adcmstime){
		adcevent |= ADCBATT;
	}

	sw_stat = sw_stat << 1;
	sw_stat = sw_stat | (0x01 & (~(uint8_t)HAL_GPIO_ReadPin(PUSHSW_GPIO_Port, PUSHSW_Pin)));
//char txt[4];
//	bin2hex4d(sw_stat, txt);
//	HAL_UART_Transmit(&hlpuart1, (uint8_t *)txt, 4, 100);
	if(_1SEC < pushtime){
		pushevent = PUSH1SEC;
	}
	if(0xFF == sw_stat){
		pushtime = pushtime + diffms;
	}
	else if(0 < pushtime){
//		bin2hex4d(pushtime, txt);
//		HAL_UART_Transmit(&hlpuart1, (uint8_t *)txt, 4, 100);
		if(0 == pushevent){
			if((_0SEC01 < pushtime)){
				pushevent = PUSH0SEC;
				pushtime = 0;
			}
		}
	}
}

uint8_t light2ev(uint16_t avg_light){
	uint8_t ev = 0;

	while(avg_light > ev_table[ev]){
		ev++;
	}
	return ev;
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC_Init();
  MX_LPUART1_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */



  // PowerHold
  HAL_GPIO_WritePin(P_HOLD_GPIO_Port, P_HOLD_Pin, GPIO_PIN_SET);

  //Start PWM
  HAL_TIM_PWM_Start (&htim2, TIM_CHANNEL_4);

  //first brink
  HAL_GPIO_WritePin(EV0_GPIO_Port, EV0_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(EV1_GPIO_Port, EV1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(EV2_GPIO_Port, EV2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(EV3_GPIO_Port, EV3_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(EV4_GPIO_Port, EV4_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(SCAN_MODE_GPIO_Port, SCAN_MODE_Pin, GPIO_PIN_SET);
  HAL_Delay(500);
  HAL_GPIO_WritePin(EV0_GPIO_Port, EV0_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(EV1_GPIO_Port, EV1_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(EV2_GPIO_Port, EV2_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(EV3_GPIO_Port, EV3_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(EV4_GPIO_Port, EV4_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(SCAN_MODE_GPIO_Port, SCAN_MODE_Pin, GPIO_PIN_RESET);
  HAL_Delay(200);


  HAL_GPIO_WritePin(EV0_GPIO_Port, EV0_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(EV1_GPIO_Port, EV1_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(EV2_GPIO_Port, EV2_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(EV3_GPIO_Port, EV3_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(EV4_GPIO_Port, EV4_Pin, GPIO_PIN_SET);

  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(SCAN_MODE_GPIO_Port, SCAN_MODE_Pin, GPIO_PIN_RESET);

  HAL_Delay(100);


  HAL_ADCEx_Calibration_Start(&hadc, ADC_SINGLE_ENDED);
//  if (HAL_ADCEx_Calibration_Start(&hadc, ADC_SINGLE_ENDED) != HAL_OK)
//    {
//      /* Calibration Error */
//      char txtadcerr[] = "AdcCalibErr\r\n";
//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtadcerr, sizeof(txtadcerr), 100);
//      Error_Handler();
//    }


//  __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_UPDATE);
//  HAL_ADC_Start_DMA (&hadc, (uint32_t *)adc_buf, 2);
//  HAL_TIM_Base_Start_IT (&htim2);
//  HAL_TIM_Base_Start (&htim2);





  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  uint8_t switch_release = 0;
  uint8_t loop_count = 0;
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  // Generate ms edge
	  if(last_ticktime < HAL_GetTick()){
		  ms_edge(HAL_GetTick() - last_ticktime);
	  }
	  last_ticktime = HAL_GetTick();


	  //PowerON Switch init
	  if(0 == switch_release){
		  if(1 == (uint8_t)HAL_GPIO_ReadPin(PUSHSW_GPIO_Port, PUSHSW_Pin)){
			  HAL_Delay(10);
			  pushtime = 0;
			  switch_release = 1;
		  }
		  pushtime = 0;
	  }

	  //Auto OFF
	  if(0 == (uint8_t)HAL_GPIO_ReadPin(PUSHSW_GPIO_Port, PUSHSW_Pin)){
		  offcount = 0;
	  }
	  if(AUTOOFFTIME < offcount){
		  // Power OFF
		  HAL_GPIO_WritePin(P_HOLD_GPIO_Port, P_HOLD_Pin, GPIO_PIN_RESET);
	  }




//	  Debug UART
      char looptxt[2];
      char txtsplit[] = ":";






      // ADC : LIGHT
      uint16_t light = 0;
      if(0 != (ADCLIGHT & adcevent)){
    	  bin2hex2d(loop_count, looptxt);
    	  HAL_UART_Transmit(&hlpuart1, (uint8_t *)looptxt, 2, 100);
    	  HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);

          HAL_ADC_Stop(&hadc);

          //ADC init for light
//          ADC_ChannelConfTypeDef sConfig = {0};
          hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
          HAL_ADC_Init(&hadc);

//          sConfig.Channel = ADC_CHANNEL_0;
//          sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
//          if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
//          {
//            Error_Handler();
//          }

    	  HAL_ADC_Start(&hadc);
          if(HAL_ADC_PollForConversion(&hadc, 10) != HAL_OK){
        	  //ADC Fail
        	  HAL_ADC_Stop(&hadc);
        	  char txtadcrunerr[] = "AdcRunErr\r\n";
        	  HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtadcrunerr, sizeof(txtadcrunerr), 100);
          }
          else{
        	  adcevent = adcevent & (~ADCLIGHT);
        	  HAL_ADC_Stop(&hadc);
//        	  light = HAL_ADC_GetValue(&hadc);
        	  que_light[que_light_point] = HAL_ADC_GetValue(&hadc);
        	  que_light_point = 0x7 & (que_light_point + 1);
        	  avg_light = 0;
        	  for(int i=0; 8 > i; i++){
        		  avg_light = avg_light + que_light[i];
        	  }

        	  bin2hex4d(avg_light, looptxt);
        	  HAL_UART_Transmit(&hlpuart1, (uint8_t *)looptxt, 4, 100);

        	  uint8_t evled = light2ev(avg_light);

        	  if(0 == viewmode){
				  HAL_GPIO_WritePin(EV0_GPIO_Port, EV0_Pin, ((~evled)) & 0x1);
				  HAL_GPIO_WritePin(EV1_GPIO_Port, EV1_Pin, ((~evled)>>1) & 0x1);
				  HAL_GPIO_WritePin(EV2_GPIO_Port, EV2_Pin, ((~evled)>>2) & 0x1);
				  HAL_GPIO_WritePin(EV3_GPIO_Port, EV3_Pin, ((~evled)>>3) & 0x1);
				  HAL_GPIO_WritePin(EV4_GPIO_Port, EV4_Pin, ((~evled)>>4) & 0x1);
        	  }

          }
      }


      // ADC : BATT

      if(0 != (ADCBATT & adcevent)){

          HAL_ADC_Stop(&hadc);

          //ADC init for Battery
//          ADC_ChannelConfTypeDef sConfig = {0};
          hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_BACKWARD;
          HAL_ADC_Init(&hadc);
//          sConfig.Channel = ADC_CHANNEL_1;
//          sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
//          if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
//          {
//            Error_Handler();
//          }

    	  HAL_ADC_Start(&hadc);

		  if(HAL_ADC_PollForConversion(&hadc, 10) != HAL_OK){
			  //ADC Fail
			  HAL_ADC_Stop(&hadc);
			  char txtadcrunerr[] = "AdcRunErr\r\n";
			  HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtadcrunerr, sizeof(txtadcrunerr), 100);
		  }
		  else{
			  adcevent = adcevent & (~ADCBATT);
			  HAL_ADC_Stop(&hadc);
			  batt = HAL_ADC_GetValue(&hadc);

			  HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);
			  HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);
			  bin2hex4d(batt, looptxt);
			  HAL_UART_Transmit(&hlpuart1, (uint8_t *)looptxt, 4, 100);

		      char txtreturn[] = "\r\n";
		      HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtreturn, sizeof(txtreturn), 100);

		  }
      }

//      HAL_ADC_Stop(&hadc);
//
//
//      HAL_ADC_Start(&hadc);
//      if(HAL_ADC_PollForConversion(&hadc, 100) != HAL_OK){
//    	  //ADC Fail
//          HAL_ADC_Stop(&hadc);
////          char txtadcrunerr[] = "AdcRunErr\r\n";
////          HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtadcrunerr, sizeof(txtadcrunerr), 100);
//      }
//      else{
//          HAL_ADC_Stop(&hadc);
//          light = HAL_ADC_GetValue(&hadc);
//      }



      //SET to LED

/*
      uint8_t ev[5];

      ev[0] = (~light) & 0x1;
      ev[1] = ((~light) >> 1) & 0x1;
      ev[2] = ((~light) >> 2) & 0x1;
      ev[3] = ((~light) >> 3) & 0x1;
      ev[4] = ((~light) >> 4) & 0x1;
*/



/*
      if(0x0 == ev[0]){
    	  HAL_GPIO_WritePin(EV0_GPIO_Port, EV0_Pin, GPIO_PIN_RESET);
      }
      else{
    	  HAL_GPIO_WritePin(EV0_GPIO_Port, EV0_Pin, GPIO_PIN_SET);
      }

      if(0x0 == ev[1]){
    	  HAL_GPIO_WritePin(EV1_GPIO_Port, EV1_Pin, GPIO_PIN_RESET);
      }
      else{
    	  HAL_GPIO_WritePin(EV1_GPIO_Port, EV1_Pin, GPIO_PIN_SET);
      }

      if(0x0 == ev[2]){
    	  HAL_GPIO_WritePin(EV2_GPIO_Port, EV2_Pin, GPIO_PIN_RESET);
      }
      else{
    	  HAL_GPIO_WritePin(EV2_GPIO_Port, EV2_Pin, GPIO_PIN_SET);
      }

      if(0x0 == ev[3]){
    	  HAL_GPIO_WritePin(EV3_GPIO_Port, EV3_Pin, GPIO_PIN_RESET);
      }
      else{
    	  HAL_GPIO_WritePin(EV3_GPIO_Port, EV3_Pin, GPIO_PIN_SET);
      }

      if(0x0 == ev[4]){
    	  HAL_GPIO_WritePin(EV3_GPIO_Port, EV4_Pin, GPIO_PIN_RESET);
      }
      else{
    	  HAL_GPIO_WritePin(EV3_GPIO_Port, EV4_Pin, GPIO_PIN_SET);
      }
*/




      // ADC : BATT
//      HAL_ADC_Stop(&hadc);
//
//
//      HAL_ADC_Start(&hadc);
//      if(HAL_ADC_PollForConversion(&hadc, 100) != HAL_OK){
//    	  //ADC Fail
//          HAL_ADC_Stop(&hadc);
////          char txtadcrunerr[] = "AdcRunErr\r\n";
////          HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtadcrunerr, sizeof(txtadcrunerr), 100);
//      }
//      else{
//          HAL_ADC_Stop(&hadc);
//          light = HAL_ADC_GetValue(&hadc);
//      }

//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);
//      bin2hex4d(adc_buf[1], looptxt);
//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)looptxt, 4, 100);
//
//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);
//      bin2hex4d(adc_buf[2], looptxt);
//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)looptxt, 4, 100);
//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);
//      bin2hex4d(adc_buf[3], looptxt);
//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)looptxt, 4, 100);
//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);
//      bin2hex4d(adc_buf[4], looptxt);
//      HAL_UART_Transmit(&hlpuart1, (uint8_t *)looptxt, 4, 100);








//      uint8_t sw_stat = (uint8_t)HAL_GPIO_ReadPin(PUSHSW_GPIO_Port, PUSHSW_Pin);



//	  HAL_Delay(200);

//	  if((0 == sw_stat) && (1 == switch_release)){

      //Button
	  if(1 == switch_release){
		  if(PUSH1SEC == pushevent){
			  // Power OFF
			  HAL_GPIO_WritePin(P_HOLD_GPIO_Port, P_HOLD_Pin, GPIO_PIN_RESET);
			  HAL_TIM_PWM_Stop (&htim2, TIM_CHANNEL_4);
		  }
		  else if(PUSH0SEC == pushevent){
			  //View mode toggle
		      char txtviewtgl[] = "ViewTGL";
		      HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtviewtgl, sizeof(txtviewtgl), 100);
			  viewmode = 0x1 & (~viewmode);
			  pushevent = 0;
		  }
		  else{
			  pushevent = 0;
		  }
	  }


	  //MODE LED Color
	  if(BATTLIMIT > batt){
		  modecolor = COLOR_RED;
	  }
	  else{
		  modecolor = COLOR_BLUE;
	  }

	  //MODE LED Control
	  if(viewmode == SCANVIEW){
		  if(1 == blink){ //bright
			  if(COLOR_BLUE == modecolor){  //normal battery state
				  HAL_GPIO_WritePin(SCAN_MODE_GPIO_Port, SCAN_MODE_Pin, GPIO_PIN_RESET);
				  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_SET);
			  }
			  else{  // low battery state
				  HAL_GPIO_WritePin(SCAN_MODE_GPIO_Port, SCAN_MODE_Pin, GPIO_PIN_SET);
				  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_RESET);
			  }
		  }
		  else{ // dark
			  HAL_GPIO_WritePin(SCAN_MODE_GPIO_Port, SCAN_MODE_Pin, GPIO_PIN_SET);
			  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_SET);
		  }
	  }
	  else{ //HOLDVIEW
		  if(COLOR_BLUE == modecolor){ // normal battey state
			  HAL_GPIO_WritePin(SCAN_MODE_GPIO_Port, SCAN_MODE_Pin, GPIO_PIN_RESET);
			  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_SET);
		  }
		  else{ // low battery state
			  HAL_GPIO_WritePin(SCAN_MODE_GPIO_Port, SCAN_MODE_Pin, GPIO_PIN_SET);
			  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_RESET);
		  }
	  }



      loop_count++;

//	  HAL_TIM_Base_Stop(&htim2);
//	  __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_UPDATE);
//	  HAL_ADC_Stop_DMA(&hadc);
//	  HAL_ADC_Start_DMA (&hadc, (uint32_t *) adc_buf, 2);
//	  HAL_TIM_Base_Start_IT (&htim2);

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage 
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_LPUART1;
  PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
  */
  hadc.Instance = ADC1;
  hadc.Init.OversamplingMode = DISABLE;
  hadc.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.SamplingTime = ADC_SAMPLETIME_160CYCLES_5;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ContinuousConvMode = ENABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerFrequencyMode = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel to be converted. 
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel to be converted. 
  */
  sConfig.Channel = ADC_CHANNEL_1;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief LPUART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPUART1_UART_Init(void)
{

  /* USER CODE BEGIN LPUART1_Init 0 */

  /* USER CODE END LPUART1_Init 0 */

  /* USER CODE BEGIN LPUART1_Init 1 */

  /* USER CODE END LPUART1_Init 1 */
  hlpuart1.Instance = LPUART1;
  hlpuart1.Init.BaudRate = 9600;
  hlpuart1.Init.WordLength = UART_WORDLENGTH_8B;
  hlpuart1.Init.StopBits = UART_STOPBITS_1;
  hlpuart1.Init.Parity = UART_PARITY_NONE;
  hlpuart1.Init.Mode = UART_MODE_TX;
  hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_HalfDuplex_Init(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LPUART1_Init 2 */

  /* USER CODE END LPUART1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 15;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(P_HOLD_GPIO_Port, P_HOLD_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, EV2_Pin|SCAN_MODE_Pin|EV3_Pin|EV4_Pin 
                          |EV0_Pin|EV1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(BATT_LOW_GPIO_Port, BATT_LOW_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PUSHSW_Pin */
  GPIO_InitStruct.Pin = PUSHSW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(PUSHSW_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : P_HOLD_Pin */
  GPIO_InitStruct.Pin = P_HOLD_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(P_HOLD_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : EV2_Pin SCAN_MODE_Pin EV3_Pin EV4_Pin 
                           EV0_Pin EV1_Pin */
  GPIO_InitStruct.Pin = EV2_Pin|SCAN_MODE_Pin|EV3_Pin|EV4_Pin 
                          |EV0_Pin|EV1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : BATT_LOW_Pin */
  GPIO_InitStruct.Pin = BATT_LOW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(BATT_LOW_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

void HAL_ADC_ConvCpltCallback (ADC_HandleTypeDef * hadc){
//	  HAL_TIM_Base_Stop(&htim2);
//	  __HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_UPDATE);
//	  HAL_ADC_Stop_DMA(&hadc);
//	  HAL_ADC_Start_DMA (&hadc, (uint32_t *) adc_buf, 4);
//	  HAL_TIM_Base_Start_IT (&htim2);

	char txtsplit[] = "@";
	      HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);

}

void HAL_SYSTICK_Callback(){
//
//	char txtsplit[] = "(";
//	HAL_UART_Transmit(&hlpuart1, (uint8_t *)txtsplit, sizeof(txtsplit), 100);
//
//
//	adcmstime++;
//	if(ADCLOOPTIME >= adcmstime){
//		adcmstime = 0;
//	}
//
//	if(ADCLIGHTTIME == adcmstime){
//		adcevent |= ADCLIGHT;
//	}
//	if(ADCBATTTIME == adcmstime){
//		adcevent |= ADCBATT;
//	}
//
//	sw_stat = sw_stat << 1;
//	sw_stat = sw_stat | (0x01 & (~(uint8_t)HAL_GPIO_ReadPin(PUSHSW_GPIO_Port, PUSHSW_Pin)));
//	if(0xFF == sw_stat){
//		pushtime++;
//	}
//	else{
//		if(0 == pushevent){
//			if(_2SEC < pushtime){
//				pushevent = PUSH3SEC;
//			}
//			else if(0 < pushtime){
//				pushevent = PUSH0SEC;
//			}
//		}
//	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
